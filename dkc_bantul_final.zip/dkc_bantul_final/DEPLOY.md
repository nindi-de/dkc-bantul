# Deploy DKC Bantul

## Supabase
1. Create a Supabase project.
2. SQL Editor → paste `supabase/schema.sql` → Run.
3. Authentication → Users → Add user (email/password).
4. Copy the user's UUID.
5. Run:
```sql
update public.profiles set role='admin' where id='USER_UUID_HERE';
```
6. In Auth settings, configure Site URL and redirect URLs for the production domain.
7. Have the admin log in and enroll TOTP at `/admin/mfa`.

## Cloudflare Turnstile
Create a Turnstile site for the production domain. Put the site key in `NEXT_PUBLIC_TURNSTILE_SITE_KEY` and secret in `TURNSTILE_SECRET_KEY`.

## Hosting
For Vercel:
- Import the project/repository.
- Framework: Next.js.
- Node.js: 22.x.
- Add all variables from `.env.production.example`.
- Deploy.

## First smoke test
- `/` loads and shows logo.
- Submit a feedback with Turnstile.
- Anonymous visitor cannot access `/admin`.
- Admin with password but without MFA cannot mutate content.
- Admin with AAL2 can add/edit/delete content.
- Image upload accepts only JPG/PNG/WebP ≤5 MB.
- CSV/Excel/PDF export works.
- `/api/admin/export` returns 403 for a non-MFA session.
- Admin can view audit logs directly from Supabase SQL (or add a dedicated audit screen if needed).
