export const MAX_IMAGE_BYTES=5*1024*1024
export const ALLOWED_IMAGE_TYPES=['image/jpeg','image/png','image/webp']
export function safeFileExtension(type:string){return type==='image/png'?'png':type==='image/webp'?'webp':'jpg'}
export function escapeCsv(value:unknown){const s=String(value??'');return '"'+s.replaceAll('"','""')+'"'}
