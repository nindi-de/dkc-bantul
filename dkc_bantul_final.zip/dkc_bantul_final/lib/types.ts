export type Role='admin'|'editor'
export type Program={id:string;title:string;status:'rencana'|'berjalan'|'selesai';description:string;created_at:string;updated_at:string}
export type Activity={id:string;title:string;date:string;location:string;description:string;image_url:string|null;created_at:string;updated_at:string}
export type Member={id:string;name:string;position:string;photo_url:string|null;created_at:string;updated_at:string}
export type Information={id:string;title:string;body:string;published:boolean;created_at:string;updated_at:string}
export type Feedback={id:string;name:string;message:string;status:'baru'|'dibaca'|'ditindaklanjuti';created_at:string}
