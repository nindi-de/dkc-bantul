import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'
export async function proxy(request:NextRequest){
  let response=NextResponse.next({request})
  const supabase=createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,{cookies:{getAll(){return request.cookies.getAll()},setAll(cookiesToSet){cookiesToSet.forEach(({name,value})=>request.cookies.set(name,value));response=NextResponse.next({request});cookiesToSet.forEach(({name,value,options})=>response.cookies.set(name,value,options))}}})
  const {data:{claims}}=await supabase.auth.getClaims()
  const path=request.nextUrl.pathname
  if(path.startsWith('/admin') && !path.startsWith('/admin/login') && !path.startsWith('/admin/mfa')){
    if(!claims){return NextResponse.redirect(new URL('/admin/login',request.url))}
  }
  return response
}
export const config={matcher:['/admin/:path*','/api/admin/:path*']}
