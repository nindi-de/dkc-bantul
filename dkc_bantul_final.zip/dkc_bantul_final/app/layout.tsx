import type { Metadata } from 'next'
import './globals.css'
export const metadata:Metadata={title:'DKC Bantul | Dewan Kerja Cabang Bantul',description:'Portal informasi resmi DKC Bantul'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="id"><body>{children}</body></html>}
