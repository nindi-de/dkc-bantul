# DKC Bantul — Final Production Starter

Website publik + dashboard admin untuk DKC Bantul.

## Stack
- Next.js 16.3.8 (Active LTS)
- React 19.3
- Supabase Auth + PostgreSQL + Storage
- SSR cookie session dengan `@supabase/ssr`
- Row Level Security (RLS)
- TOTP MFA AAL2 wajib untuk operasi admin
- Cloudflare Turnstile untuk kritik & saran di production
- Export CSV yang kompatibel dengan Excel + PDF
- Upload JPG/PNG/WebP maksimal 5 MB
- Audit log perubahan konten

## 1. Persiapan
1. Install Node.js 22 LTS atau lebih baru.
2. Buat project Supabase.
3. Di Supabase SQL Editor, jalankan `supabase/schema.sql`.
4. Buat user admin di Supabase Authentication > Users.
5. Jalankan SQL promosi admin:
   `update public.profiles set role='admin' where id=(select id from auth.users where email='EMAIL_ADMIN');`
6. Aktifkan/siapkan TOTP MFA di aplikasi. Login pertama akan membawa admin ke halaman MFA.
7. Salin `.env.example` menjadi `.env.local` dan isi URL + publishable key.
8. Untuk production, isi `TURNSTILE_SECRET_KEY` dan `NEXT_PUBLIC_TURNSTILE_SITE_KEY`.

## 2. Jalankan
```bash
npm install
npm run typecheck
npm run build
npm start
```

## 3. Deploy
Paling sederhana: deploy repository ini ke Vercel atau platform Next.js lain. Tambahkan environment variables yang sama di dashboard deployment.

## 4. Keamanan penting
- Jangan pernah memasukkan Supabase `service_role` key ke browser, `.env.example`, Git, atau kode frontend.
- Gunakan publishable key untuk browser.
- Jangan menonaktifkan RLS.
- Gunakan akun admin terpisah dari akun pribadi.
- Wajibkan MFA untuk semua akun staff.
- Gunakan domain HTTPS.
- Aktifkan backup database/PITR sesuai kebutuhan.
- Ganti kredensial jika pernah terlanjur masuk Git.
- Untuk production, Turnstile harus dikonfigurasi; endpoint feedback akan menolak request jika secret belum tersedia.

## 5. Fitur
Publik: profil, statistik, program kerja, kegiatan, pengurus, informasi, kritik & saran.
Admin: dashboard, CRUD program/kegiatan/pengurus/informasi, kelola feedback, upload foto, export CSV, MFA, audit log database.

### Catatan “100% siap”
Source ini dibuat sebagai paket production-ready yang harus dikonfigurasi ke project Supabase milik DKC Bantul. Tidak ada source code yang dapat menjamin keamanan 100%; keamanan final juga bergantung pada konfigurasi hosting, DNS/HTTPS, Supabase, MFA, backup, dan pengelolaan akun.
